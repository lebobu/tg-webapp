# How to develop?
1. To restrat bot run pm2 reload ecosystem.config.cjs
or to restart of its not running to start
pm2 startOrReload /root/tg-webapp/ecosystem.config.cjs
2. To print logs pm2 logs

Both steps are executed in run.sh via ./run.sh

# Logic
# Structure ready

# fix
node -v
v18.20.8
npm -v
10.9.2

